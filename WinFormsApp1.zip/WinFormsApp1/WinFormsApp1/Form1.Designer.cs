﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CEbutton = new System.Windows.Forms.Button();
            this.speakFunctionButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.linkButton = new System.Windows.Forms.Button();
            this.sendButton = new System.Windows.Forms.Button();
            this.writeTextBox = new System.Windows.Forms.TextBox();
            this.readTextBox = new System.Windows.Forms.TextBox();
            this.lightnessLabel = new System.Windows.Forms.Label();
            this.CMDButton4 = new System.Windows.Forms.Button();
            this.CMDButton3 = new System.Windows.Forms.Button();
            this.stateLabel = new System.Windows.Forms.Label();
            this.stateValue = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.CMDButton2 = new System.Windows.Forms.Button();
            this.lightnessValue = new System.Windows.Forms.Label();
            this.CMDButton1 = new System.Windows.Forms.Button();
            this.portsComboBox = new System.Windows.Forms.ComboBox();
            this.humidityValue = new System.Windows.Forms.Label();
            this.connectButton = new System.Windows.Forms.Button();
            this.humidityLabel = new System.Windows.Forms.Label();
            this.searchButton = new System.Windows.Forms.Button();
            this.ATemperaValue = new System.Windows.Forms.Label();
            this.controlLabel = new System.Windows.Forms.Label();
            this.ATemperaLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CEbutton
            // 
            this.CEbutton.BackColor = System.Drawing.Color.Orange;
            this.CEbutton.Location = new System.Drawing.Point(787, 6);
            this.CEbutton.Name = "CEbutton";
            this.CEbutton.Size = new System.Drawing.Size(112, 52);
            this.CEbutton.TabIndex = 20;
            this.CEbutton.Text = "中文";
            this.CEbutton.UseVisualStyleBackColor = false;
            this.CEbutton.Click += new System.EventHandler(this.CEButton_Click);
            // 
            // speakFunctionButton
            // 
            this.speakFunctionButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.speakFunctionButton.Location = new System.Drawing.Point(584, 6);
            this.speakFunctionButton.Name = "speakFunctionButton";
            this.speakFunctionButton.Size = new System.Drawing.Size(197, 52);
            this.speakFunctionButton.TabIndex = 21;
            this.speakFunctionButton.Text = "Open speak system";
            this.speakFunctionButton.UseVisualStyleBackColor = true;
            this.speakFunctionButton.Click += new System.EventHandler(this.speakButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("得意黑", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Firebrick;
            this.label9.Location = new System.Drawing.Point(284, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(374, 53);
            this.label9.TabIndex = 22;
            this.label9.Text = "Hutao Shake Toy Tool";
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(225, 262);
            // 
            // linkButton
            // 
            this.linkButton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.linkButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.linkButton.Location = new System.Drawing.Point(466, 6);
            this.linkButton.Name = "linkButton";
            this.linkButton.Size = new System.Drawing.Size(112, 52);
            this.linkButton.TabIndex = 23;
            this.linkButton.Text = "github >";
            this.linkButton.UseVisualStyleBackColor = false;
            this.linkButton.Click += new System.EventHandler(this.button11_Click);
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(736, 500);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(112, 34);
            this.sendButton.TabIndex = 5;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // writeTextBox
            // 
            this.writeTextBox.Location = new System.Drawing.Point(488, 364);
            this.writeTextBox.Multiline = true;
            this.writeTextBox.Name = "writeTextBox";
            this.writeTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.writeTextBox.Size = new System.Drawing.Size(360, 115);
            this.writeTextBox.TabIndex = 4;
            // 
            // readTextBox
            // 
            this.readTextBox.Location = new System.Drawing.Point(488, 173);
            this.readTextBox.Multiline = true;
            this.readTextBox.Name = "readTextBox";
            this.readTextBox.ReadOnly = true;
            this.readTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.readTextBox.Size = new System.Drawing.Size(360, 115);
            this.readTextBox.TabIndex = 3;
            // 
            // lightnessLabel
            // 
            this.lightnessLabel.AutoSize = true;
            this.lightnessLabel.Location = new System.Drawing.Point(17, 69);
            this.lightnessLabel.Name = "lightnessLabel";
            this.lightnessLabel.Size = new System.Drawing.Size(100, 24);
            this.lightnessLabel.TabIndex = 9;
            this.lightnessLabel.Text = "Lightness: ";
            // 
            // CMDButton4
            // 
            this.CMDButton4.Location = new System.Drawing.Point(314, 499);
            this.CMDButton4.Name = "CMDButton4";
            this.CMDButton4.Size = new System.Drawing.Size(112, 34);
            this.CMDButton4.TabIndex = 19;
            this.CMDButton4.Text = "Lighter";
            this.CMDButton4.UseVisualStyleBackColor = true;
            this.CMDButton4.Click += new System.EventHandler(this.button8_Click);
            // 
            // CMDButton3
            // 
            this.CMDButton3.Location = new System.Drawing.Point(163, 499);
            this.CMDButton3.Name = "CMDButton3";
            this.CMDButton3.Size = new System.Drawing.Size(112, 34);
            this.CMDButton3.TabIndex = 18;
            this.CMDButton3.Text = "Darker";
            this.CMDButton3.UseVisualStyleBackColor = true;
            this.CMDButton3.Click += new System.EventHandler(this.button7_Click);
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(17, 27);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(63, 24);
            this.stateLabel.TabIndex = 7;
            this.stateLabel.Text = "State: ";
            // 
            // stateValue
            // 
            this.stateValue.AutoSize = true;
            this.stateValue.Location = new System.Drawing.Point(108, 27);
            this.stateValue.Name = "stateValue";
            this.stateValue.Size = new System.Drawing.Size(25, 24);
            this.stateValue.TabIndex = 10;
            this.stateValue.Text = "   ";
            // 
            // closeButton
            // 
            this.closeButton.Enabled = false;
            this.closeButton.Location = new System.Drawing.Point(241, 238);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(112, 34);
            this.closeButton.TabIndex = 6;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // CMDButton2
            // 
            this.CMDButton2.Location = new System.Drawing.Point(314, 431);
            this.CMDButton2.Name = "CMDButton2";
            this.CMDButton2.Size = new System.Drawing.Size(112, 34);
            this.CMDButton2.TabIndex = 17;
            this.CMDButton2.Text = "Stop!";
            this.CMDButton2.UseVisualStyleBackColor = true;
            this.CMDButton2.Click += new System.EventHandler(this.button6_Click);
            // 
            // lightnessValue
            // 
            this.lightnessValue.AutoSize = true;
            this.lightnessValue.Location = new System.Drawing.Point(108, 69);
            this.lightnessValue.Name = "lightnessValue";
            this.lightnessValue.Size = new System.Drawing.Size(25, 24);
            this.lightnessValue.TabIndex = 11;
            this.lightnessValue.Text = "   ";
            // 
            // CMDButton1
            // 
            this.CMDButton1.Location = new System.Drawing.Point(163, 431);
            this.CMDButton1.Name = "CMDButton1";
            this.CMDButton1.Size = new System.Drawing.Size(112, 34);
            this.CMDButton1.TabIndex = 16;
            this.CMDButton1.Text = "Shake!";
            this.CMDButton1.UseVisualStyleBackColor = true;
            this.CMDButton1.Click += new System.EventHandler(this.button5_Click);
            // 
            // portsComboBox
            // 
            this.portsComboBox.FormattingEnabled = true;
            this.portsComboBox.Location = new System.Drawing.Point(71, 173);
            this.portsComboBox.Name = "portsComboBox";
            this.portsComboBox.Size = new System.Drawing.Size(182, 32);
            this.portsComboBox.TabIndex = 1;
            // 
            // humidityValue
            // 
            this.humidityValue.AutoSize = true;
            this.humidityValue.Location = new System.Drawing.Point(293, 69);
            this.humidityValue.Name = "humidityValue";
            this.humidityValue.Size = new System.Drawing.Size(25, 24);
            this.humidityValue.TabIndex = 15;
            this.humidityValue.Text = "   ";
            // 
            // connectButton
            // 
            this.connectButton.Enabled = false;
            this.connectButton.Location = new System.Drawing.Point(71, 238);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(112, 34);
            this.connectButton.TabIndex = 2;
            this.connectButton.Text = "Connect";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectionButton_Click);
            // 
            // humidityLabel
            // 
            this.humidityLabel.AutoSize = true;
            this.humidityLabel.Location = new System.Drawing.Point(187, 70);
            this.humidityLabel.Name = "humidityLabel";
            this.humidityLabel.Size = new System.Drawing.Size(100, 24);
            this.humidityLabel.TabIndex = 13;
            this.humidityLabel.Text = "Humidity: ";
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(303, 173);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(112, 34);
            this.searchButton.TabIndex = 0;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // ATemperaValue
            // 
            this.ATemperaValue.AutoSize = true;
            this.ATemperaValue.Location = new System.Drawing.Point(293, 27);
            this.ATemperaValue.Name = "ATemperaValue";
            this.ATemperaValue.Size = new System.Drawing.Size(25, 24);
            this.ATemperaValue.TabIndex = 14;
            this.ATemperaValue.Text = "   ";
            // 
            // controlLabel
            // 
            this.controlLabel.AutoSize = true;
            this.controlLabel.Location = new System.Drawing.Point(71, 469);
            this.controlLabel.Name = "controlLabel";
            this.controlLabel.Size = new System.Drawing.Size(83, 24);
            this.controlLabel.TabIndex = 24;
            this.controlLabel.Text = "Control: ";
            // 
            // ATemperaLabel
            // 
            this.ATemperaLabel.AutoSize = true;
            this.ATemperaLabel.Location = new System.Drawing.Point(187, 27);
            this.ATemperaLabel.Name = "ATemperaLabel";
            this.ATemperaLabel.Size = new System.Drawing.Size(108, 24);
            this.ATemperaLabel.TabIndex = 12;
            this.ATemperaLabel.Text = "ATempera: ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.ATemperaLabel);
            this.panel1.Controls.Add(this.stateValue);
            this.panel1.Controls.Add(this.stateLabel);
            this.panel1.Controls.Add(this.lightnessValue);
            this.panel1.Controls.Add(this.lightnessLabel);
            this.panel1.Controls.Add(this.humidityValue);
            this.panel1.Controls.Add(this.humidityLabel);
            this.panel1.Controls.Add(this.ATemperaValue);
            this.panel1.Location = new System.Drawing.Point(54, 298);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(390, 115);
            this.panel1.TabIndex = 25;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(736, 312);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(112, 34);
            this.clearButton.TabIndex = 26;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(911, 609);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.readTextBox);
            this.Controls.Add(this.writeTextBox);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.controlLabel);
            this.Controls.Add(this.linkButton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.speakFunctionButton);
            this.Controls.Add(this.CEbutton);
            this.Controls.Add(this.connectButton);
            this.Controls.Add(this.portsComboBox);
            this.Controls.Add(this.CMDButton4);
            this.Controls.Add(this.CMDButton1);
            this.Controls.Add(this.CMDButton3);
            this.Controls.Add(this.CMDButton2);
            this.Controls.Add(this.closeButton);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "HutaoShakeToyTool";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button CEbutton;
        private Button speakFunctionButton;
        private Label label9;
        private ToolStripPanel BottomToolStripPanel;
        private ToolStripPanel TopToolStripPanel;
        private ToolStripPanel RightToolStripPanel;
        private ToolStripPanel LeftToolStripPanel;
        private ToolStripContentPanel ContentPanel;
        private Button linkButton;
        private Button sendButton;
        private TextBox writeTextBox;
        private TextBox readTextBox;
        private Label lightnessLabel;
        private Button CMDButton4;
        private Button CMDButton3;
        private Label stateLabel;
        private Label stateValue;
        private Button closeButton;
        private Button CMDButton2;
        private Label lightnessValue;
        private Button CMDButton1;
        private ComboBox portsComboBox;
        private Label humidityValue;
        private Button connectButton;
        private Label humidityLabel;
        private Button searchButton;
        private Label ATemperaValue;
        private Label controlLabel;
        private Label ATemperaLabel;
        private Panel panel1;
        private Button clearButton;
    }
}