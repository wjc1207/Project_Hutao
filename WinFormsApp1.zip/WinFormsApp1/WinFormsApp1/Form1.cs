using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO.Ports;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;
using SpeechLib;
using static System.Net.Mime.MediaTypeNames;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        //define consts
        const Boolean English = false;
        const Boolean Chinese = true;
        private Boolean speakState = false;
        private Boolean CEState = English;
        private Boolean connectionState = false;

        // Constructor
        public Form1()
        {
            InitializeComponent();
        }

        // Initialize SerialPort
        private SerialPort serialPort = new SerialPort();

        // Search Button Click event handler
        private void button1_Click(object sender, EventArgs e)
        {
            ObservableCollection<string> ports = new ObservableCollection<string>();
            string[] portNames = SerialPort.GetPortNames();
            foreach (string portName in portNames)
            {
                ports.Add(portName);
            }
            portsComboBox.DataSource = ports;
            speak("������ɣ�", "Search Done!");
            if (portsComboBox.SelectedItem.ToString() != null && connectionState == false) //connection condition: object != null && no connection
            {
                connectButton.Enabled = true;
            }
        }


        // Connect Button Click event handler
        private void connectionButton_Click(object sender, EventArgs e)
        {
            if (portsComboBox.SelectedItem.ToString() != null && connectionState == false)
            { 
                // Set serial port parameters
                serialPort.PortName = portsComboBox.SelectedItem.ToString();
                serialPort.BaudRate = 115200;
                serialPort.DataBits = 8;
                serialPort.Parity = Parity.None;
                serialPort.StopBits = StopBits.One;

                // Open serial port
                serialPort.Open();
                serialPort.DataReceived += new SerialDataReceivedEventHandler(Serial_Received);
                speak("�ɹ��򿪴��ڣ�", "open serial port successfully!");
                connectionState= true;
                connectButton.Enabled = false;
                closeButton.Enabled = true;
            }
        }

        // SerialPort DataReceived event handler
        private void Serial_Received(object sender, SerialDataReceivedEventArgs e)
        {
            string s = serialPort.ReadExisting();
            // This code block is invoking a new Action to execute the following code block
            this.Invoke(new Action(() =>
            {
                // Parse the input string 's'
                if (s.Split(',')[0] == "MEG")
                {
                    // If the first element in the comma-separated list is "MEG"
                    // Set the text of 'label3' to the second element in the list
                    stateValue.Text = s.Split(',')[1];
                    // Check the third element in the list and set 'label4' accordingly
                    if (s.Split(',')[2] == "121")
                    {
                        lightnessValue.Text = "----";
                    }
                    else if (s.Split(',')[2] == "40")
                    {
                        lightnessValue.Text = "--";
                    }
                    else
                    {
                        lightnessValue.Text = "-------";
                    }

                    // Set the text of 'label7' to the fourth element in the list followed by "C"
                    ATemperaValue.Text = s.Split(',')[3] + "C";

                    // Set the text of 'label8' to the fifth element in the list followed by "%"
                    humidityValue.Text = s.Split(",")[4] + "%";
                }

                // Append the input string 's' to the 'textBox1' control
                readTextBox.AppendText(s);

            }));
        }

        // Send Button Click event handler
        private void button3_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(writeTextBox.Text) && connectionState == true)
            {
                serialPort.Write(writeTextBox.Text);
                speak("���ݷ��ͳɹ���", "send message successfully!");
            }
        }

        // Close Button Click event handler
        private void closeButton_Click(object sender, EventArgs e)
        {
            if (connectionState == true)
            {
                serialPort.Close();
                speak("�ɹ��رմ��ڣ�", "close serial port successfully!");
                stateValue.Text = null;
                ATemperaValue.Text = null;
                lightnessValue.Text = null;
                humidityValue.Text = null;
                connectionState = false;
                connectButton.Enabled = true;
                closeButton.Enabled = false;
            }
                
            
        }

        //send CMD to the MCU to drive the motor work
        private void button5_Click(object sender, EventArgs e)
        {
            if (connectionState == true)
            {
                string message = "CMD,M,1";
                byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
                serialPort.Write(asciiBytes, 0, asciiBytes.Length);
                speak("�����ɹ���", "operate successfully!");
            }
        }

        //send CMD to the MCU to stop the motor
        private void button6_Click(object sender, EventArgs e)
        {
            if (connectionState == true)
            {
                string message = "CMD,M,0";
                byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
                serialPort.Write(asciiBytes, 0, asciiBytes.Length);
                speak("�����ɹ���", "operate successfully!");
            }
        }

        //send CMD to the MCU to make the RGB light darker
        private void button7_Click(object sender, EventArgs e)
        {
            if (connectionState == true)
            {
                string message = "CMD,L,-1";
                byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
                serialPort.Write(asciiBytes, 0, asciiBytes.Length);
                speak("�����ɹ���", "operate successfully!");
            }
        }

        //send CMD to the MCU to make the RGB light brighter
        private void button8_Click(object sender, EventArgs e)
        {
            if (connectionState == true)
            {
                string message = "CMD,L,1";
                byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
                serialPort.Write(asciiBytes, 0, asciiBytes.Length);
                speak("�����ɹ���", "operate successfully!");
            }
        }

        //translation
        private void CEButton_Click(object sender, EventArgs e)
        {
            if (CEbutton.Text == "����")
            {
                searchButton.Text = "����";
                connectButton.Text = "����";
                sendButton.Text = "����";
                closeButton.Text = "�ر�";
                stateLabel.Text = "״̬: ";
                lightnessLabel.Text = "����: ";
                ATemperaLabel.Text = "����¶�: ";
                humidityLabel.Text = "ʪ��: ";
                controlLabel.Text = "����: ";
                CMDButton1.Text = "����";
                CMDButton2.Text = "ֹͣ";
                CMDButton3.Text = "�䰵";
                CMDButton4.Text = "����";
                CEbutton.Text = "English";
                clearButton.Text = "���";
                if (speakState == true) //trigger 1
                {
                    speakFunctionButton.Text = "�ر�����ϵͳ";
                    speakFunctionButton.BackColor= Color.Green;
                }
                else
                {
                    speakFunctionButton.Text = "������ϵͳ";
                    speakFunctionButton.BackColor = Color.White;
                }
                CEState = Chinese;
            }
            else
            {
                searchButton.Text = "Search";
                connectButton.Text = "Connect";
                sendButton.Text = "Send";
                closeButton.Text = "Close";
                stateLabel.Text = "State: ";
                lightnessLabel.Text = "Lightness: ";
                ATemperaLabel.Text = "ATempera: ";
                humidityLabel.Text = "Humidity: ";
                controlLabel.Text = "Control: ";
                CMDButton1.Text = "Shake!";
                CMDButton2.Text = "Stop!";
                CMDButton3.Text = "Darker";
                CMDButton4.Text = "Lighter";
                CEbutton.Text = "����";
                clearButton.Text = "Clear";
                if (speakState == true)
                {
                    speakFunctionButton.Text = "Close speak system";
                    speakFunctionButton.BackColor = Color.Green;
                }
                else
                {
                    speakFunctionButton.Text = "Open speak system";
                    speakFunctionButton.BackColor = Color.White;
                }
                CEState = English;
            }
        }
        //speak function for both Chinese and English
        public void speak(string contentChinese, string contentEnglish)
        {
            if (speakState)
            {
                string text;
                if (CEState == English)
                {
                    text = contentEnglish;
                }
                else
                {
                    text = contentChinese;
                }

                SpVoice voice = new SpVoice();
                //����
                voice.Volume = 100;
                //����
                voice.Rate = 2;
                //�ʶ�����
                voice.Speak(text);
            }
        }

        private void button11_Click(object sender, EventArgs e) //Github Link
        {
            Process.Start(new ProcessStartInfo("https://github.com/wjc74751/Project_Hutao") { UseShellExecute = true });
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            readTextBox.Text = null;
        }

        // switch for speak function
        private void speakButton_Click(object sender, EventArgs e)
        {
            if (!speakState)//trigger 2
            {
                speakState = true; //open speak function
                if (CEState == English)
                {
                    speakFunctionButton.Text = "Close speak system";
                    speakFunctionButton.BackColor = Color.Green;
                }
                else
                {
                    speakFunctionButton.Text = "�ر�����ϵͳ";
                    speakFunctionButton.BackColor = Color.Green;
                }

            }
            else
            {
                speakState = false; //close speak function
                if (CEState == English)
                {
                    speakFunctionButton.Text = "Open speak system";
                    speakFunctionButton.BackColor = Color.White;
                }
                else
                {
                    speakFunctionButton.Text = "������ϵͳ";
                    speakFunctionButton.BackColor = Color.White;
                }
            }
        }
    }
}
