using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO.Ports;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;
using SpeechLib;
using static System.Net.Mime.MediaTypeNames;

namespace WinFormsApp1
{

    public partial class Form1 : Form
    {
        const Boolean English = false;
        const Boolean Chinese = true;
        private Boolean speakState = false;
        private Boolean CEState = English;
        public Form1()
        {
            InitializeComponent();
        }
        private SerialPort serialPort = new SerialPort();
        private void button1_Click(object sender, EventArgs e)
        {
            ObservableCollection<string> ports = new ObservableCollection<string>();
            string[] portNames = SerialPort.GetPortNames();
            foreach (string portName in portNames)
            {
                ports.Add(portName);
            }
            comboBox1.DataSource = ports;
            speak("������ɣ�", "Search Done!");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            try
            {
                // ���ô��ڲ���
                serialPort.PortName = comboBox1.SelectedItem.ToString();
                serialPort.BaudRate = 115200;
                serialPort.DataBits = 8;
                serialPort.Parity = Parity.None;
                serialPort.StopBits = StopBits.One;

                // �򿪴���
                serialPort.Open();
                serialPort.DataReceived += new SerialDataReceivedEventHandler(Serial_Received);
                speak("�ɹ��򿪴��ڣ�", "open serial port successfully!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Serial_Received(object sender, SerialDataReceivedEventArgs e)
        {

            string s = serialPort.ReadExisting();
            this.Invoke(new Action(() =>
            {
                if (s.Split(',')[0] == "MEG")
                {
                    label3.Text = s.Split(',')[1];
                    if (s.Split(',')[2] == "121")
                    {
                        label4.Text = "----";
                    }
                    else if (s.Split(',')[2] == "40")
                    {
                        label4.Text = "--";
                    }
                    else
                    {
                        label4.Text = "-------";
                    }
                    label7.Text = s.Split(',')[3] + "C";
                    label8.Text = s.Split(",")[4] + "%";
                }
                textBox1.AppendText(s);
            }));
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                serialPort.Write(textBox2.Text);
                speak("���ݷ��ͳɹ���", "send message successfully!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            serialPort.Close();
            speak("�ɹ��رմ��ڣ�", "close serial port successfully!");
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string message = "CMD,M,1";
            byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
            serialPort.Write(asciiBytes, 0, asciiBytes.Length);
            speak("�����ɹ���", "operate successfully!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string message = "CMD,M,0";
            byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
            serialPort.Write(asciiBytes, 0, asciiBytes.Length);
            speak("�����ɹ���", "operate successfully!");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string message = "CMD,L,-1";
            byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
            serialPort.Write(asciiBytes, 0, asciiBytes.Length);
            speak("�����ɹ���", "operate successfully!");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string message = "CMD,L,1";
            byte[] asciiBytes = Encoding.ASCII.GetBytes(message);
            serialPort.Write(asciiBytes, 0, asciiBytes.Length);
            speak("�����ɹ���", "operate successfully!");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.Text == "����")
            {
                button1.Text = "����";
                button2.Text = "����";
                button3.Text = "����";
                button4.Text = "�ر�";
                label1.Text = "״̬: ";
                label2.Text = "����: ";
                label5.Text = "�¶�: ";
                label6.Text = "ʪ��: ";
                label10.Text = "����: ";
                button5.Text = "����";
                button6.Text = "ֹͣ";
                button7.Text = "�䰵";
                button8.Text = "����";
                button9.Text = "English";

                if (speakState == true) //trigger 1
                {
                    button10.Text = "�ر�����ϵͳ";
                    button10.BackColor= Color.Green;
                }
                else
                {
                    button10.Text = "������ϵͳ";
                    button10.BackColor = Color.White;
                }
                CEState = Chinese;
            }
            else
            {
                button1.Text = "Search";
                button2.Text = "Connect";
                button3.Text = "Send";
                button4.Text = "Close";
                label1.Text = "State: ";
                label2.Text = "Lightness: ";
                label5.Text = "Temperature: ";
                label6.Text = "Humidity: ";
                label10.Text = "Control: ";
                button5.Text = "Shake!";
                button6.Text = "Stop!";
                button7.Text = "Darker";
                button8.Text = "Lighter";
                button9.Text = "����";
                if (speakState == true)
                {
                    button10.Text = "Close speak system";
                    button10.BackColor = Color.Green;
                }
                else
                {
                    button10.Text = "Open speak system";
                    button10.BackColor = Color.White;
                }
                CEState = English;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }
        public void speak(string contentChinese, string contentEnglish)
        {
            if (speakState)
            {
                string text;
                if (CEState == English)
                {
                    text = contentEnglish;
                }
                else
                {
                    text = contentChinese;
                }

                SpVoice voice = new SpVoice();
                //����
                voice.Volume = 100;
                //����
                voice.Rate = 2;
                //�ʶ�����
                voice.Speak(text);
            }
        }


        private void button10_Click_2(object sender, EventArgs e)
        {
            if (!speakState)//trigger 2
            {
                speakState = true;
                if (CEState== English) 
                {
                    button10.Text = "Close speak system";
                    button10.BackColor = Color.Green;
                }
                else
                {
                    button10.Text = "�ر�����ϵͳ";
                    button10.BackColor = Color.Green;
                }
                
            }
            else
            {
                speakState= false;
                if (CEState == English)
                {
                    button10.Text = "Open speak system";
                    button10.BackColor = Color.White;
                }
                else
                {
                    button10.Text = "������ϵͳ";
                    button10.BackColor = Color.White;
                }
            }
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }


        private void button11_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo("https://github.com/wjc74751/Project_Hutao") { UseShellExecute = true });
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
